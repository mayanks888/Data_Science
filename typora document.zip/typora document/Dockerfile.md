docker command more

- **links**:
  - https://www.tutorialspoint.com/docker/docker_file.htm
  - https://www.digitalocean.com/community/tutorials/docker-explained-using-dockerfiles-to-automate-building-of-images
  - https://www.youtube.com/watch?v=CaBiucOrJd0&list=PLea0WJq13cnDsF4MrbNaw3b4jI0GT9yKt&t=0s&index=17
  - **docker files**
    - https://towardsdatascience.com/real-time-and-video-processing-object-detection-using-tensorflow-opencv-and-docker-2be1694726e5
    - https://github.com/sofwerx/tensorflow-object-detection-docker/blob/master/gpu_docker/Dockerfile
    - https://towardsdatascience.com/tensorflow-object-detection-with-docker-from-scratch-5e015b639b0b
    - https://github.com/tensorflow/tensorflow/blob/master/tensorflow/tools/docker/Dockerfile.gpu
    - https://github.com/itamaro/tensorflow-object-detection-app/blob/master/Dockerfile

  

- **Docker file command**

  1. **From** : It tells docker, from which base image you want to base your image from. In our example, 			we are creating an image from the ubuntu image.

     ```
     # Usage: FROM [image name]
     FROM ubuntu
     ```

  2. **Maintainer** : The next command is the person who is going to maintain this image. Here you specify the **MAINTAINER** keyword and just mention the email ID.

     ```
     # Usage: MAINTAINER [name]
     MAINTAINER authors_name
     ```

  3. **Run** : The **RUN** command is used to run instructions against the image. In our case, we first update our Ubuntu system and then install the nginx server on our **ubuntu** image.

     ```
     # Usage: RUN [command]
     RUN aptitude install -y riak
     ```

  4. **ADD** : The ADD command gets two arguments: a source and a destination. It basically copies the files from the source on the host into the container's own filesystem at the set destination. If, however, the source is a URL (e.g. <http://github.com/user/file/>), then the contents of the URL are downloaded and placed at the destination.

     Example:

     ```
     # Usage: ADD [source directory or URL] [destination directory]
     ADD /my_app_folder /my_app_folder
     ```

  5. **CMD**:The command CMD, similarly to RUN, can be used for executing a specific command. However, unlike RUN it is not executed during build, but when a container is instantiated using the image being built. Therefore, it should be considered as an initial, default command that gets executed (i.e. run) with the creation of containers based on the image.

     **To clarify:** an example for CMD would be running an application upon creation of a container which is already installed using RUN (e.g. RUN apt-get install …) inside the image. This default application execution command that is set with CMD becomes the default and replaces any command which is passed during the creation.

     Example:

     ```
     # Usage 1: CMD application "argument", "argument", ..
     CMD "echo" "Hello docker!"
     ```

  6. **ENTRYPOINT**: ENTRYPOINT argument sets the concrete default application that is used every time a container is created using the image. For example, if you have installed a specific application inside an image and you will use this image to only run that application, you can state it with ENTRYPOINT and whenever a container is created from that image, your application will be the target.

     If you couple ENTRYPOINT with CMD, you can remove "application" from CMD and just leave "arguments" which will be passed to the ENTRYPOINT.

     Example:

     ```
     # Usage: ENTRYPOINT application "argument", "argument", ..
     # Remember: arguments are optional. They can be provided by CMD
     #           or during the creation of a container.
     ENTRYPOINT echo
     
     # Usage example with CMD:
     # Arguments set with CMD can be overridden during *run*
     CMD "Hello docker!"
     ENTRYPOINT echo  
     ```

  7. **ENV**: The ENV command is used to set the environment variables (one or more). These variables consist of “key value” pairs which can be accessed within the container by scripts and applications alike. This functionality of Docker offers an enormous amount of flexibility for running programs.

     Example:

     ```
     # Usage: ENV key value
     ENV SERVER_WORKS 4
     ```

  8. **EXPOSE**

  9. **USER**: The USER directive is used to set the UID (or username) which is to run the container based on the image being built.

     Example:

     ```
     # Usage: USER [UID]
     USER 751
     ```

  10. **VOLUME**: The VOLUME command is used to enable access from your container to a directory on the host machine (i.e. mounting it).

      Example:

      ```
      # Usage: VOLUME ["/dir_1", "/dir_2" ..]
      VOLUME ["/my_files"]
      ```

  11. **WORKDIR** :The WORKDIR directive is used to set where the command defined with CMD is to be executed.

      Example:

      ```
      # Usage: WORKDIR /path
      WORKDIR ~/
      ```

  ---

  

  - **dockerfile** : instruction to build the images** 

  1. mkdir myimage : create the folder name Dockerfile

  2. cd myimage

  3. touch Dockerfile: create file name Dockerfile

  4. Nano Dockerfile

     enter the data inside docker file

     ```
     From ubuntu
     Run apt-get update
     Run apt-get install -y wget
     CMD wget -O- -q http://ifconfig.me/ip
     CMD ["echo", "hello"]
     ```

     Note : only last cmd command will work

  5. let build the docker file < enter inside the folder

     1. docker build  -t ImageName:TagName dir2
     2. docker build . {commmand to rin dockerfilw inside folder}
        or
     3. docker build -t ImageName:Tag directoryOfDocekrfile
     4. docker build -t mayank:1.0 .    {-t is for tagging the docker image}

  

