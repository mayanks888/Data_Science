Training :

```
export PYTHONPATH=$PYTHONPATH:`pwd`:`pwd`/slim
```

python object_detection/model_main.py \
    --pipeline_config_path=/tensorflow/data/config_files/ssd_mob_v2_coco.config \
    --model_dir=/tensorflow/ckpt \
    --num_train_steps=500 \
    --sample_1_of_n_eval_examples=1 \
    --alsologtostderr

cd /tensorflow/models/research

