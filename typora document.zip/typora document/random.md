https://www.youtube.com/watch?v=GGorVpzZQwA



**for pycocotools** 

**requirenment first install cython and then use make command from tensorflow installation**

better to create the virtual env with python3

1. pip install cython : make sure its is python 3 enviroment

2. pip install numpy

3. ```
   git clone https://github.com/cocodataset/cocoapi.git
   cd cocoapi/PythonAPI
   make
   cp -r pycocotools <path_to_tensorflow>/models/research/
   ```